# Portfolio Enhancement Plan

## Phase 1: Core Improvements
- [ ] Add one-line value statement to header: "Data Analyst | Python • SQL • Tableau"
- [ ] Update navigation to: Home | Projects | Skills | Certifications | Contact
- [ ] Add clear CTAs: "View Projects", "Download Resume", "Contact Me"
- [ ] Add credibility logos (IBM, Coursera, IIT Guwahati, Tata Group)
- [ ] Add "Open to internships & entry-level roles" statement

## Phase 2: Content Enhancement
- [x] Restructure projects as stories: Problem → Solution → Impact
- [x] Add quantifiable results to projects (e.g., "Improved efficiency by 30%")
- [x] Make skills more scannable with chips/badges
- [x] Add live links to all projects and certifications
- [x] Highlight key achievements with numbers

## Phase 3: UI/UX Improvements
- [ ] Enhance glassmorphism effects
- [ ] Add more hover effects and animations
- [ ] Implement skill chips instead of long paragraphs
- [ ] Add scroll animations and smooth transitions
- [ ] Ensure mobile-first responsive design

## Phase 4: Performance & Branding
- [ ] Optimize images and reduce heavy animations
- [ ] Ensure consistent colors, fonts, and tone
- [ ] Add personal branding elements
- [ ] Test 30-second rule: Can recruiters quickly understand skills/projects?

## Files to Update
- templates/index.html (main portfolio page)
- templates/about.html (about page)
- templates/projects.html (projects page)
- templates/certifications.html (certifications page)
- templates/contact.html (contact page)
- static/ (add logos and optimized images)

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

def create_resume():
    doc = SimpleDocTemplate("static/resume.pdf", pagesize=letter)
    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle('Title', parent=styles['Title'], fontSize=24, spaceAfter=30, alignment=1)
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'], fontSize=14, spaceAfter=12, textColor=colors.blue)
    normal_style = ParagraphStyle('Normal', parent=styles['Normal'], fontSize=10, spaceAfter=6)

    story = []

    # Title
    story.append(Paragraph("Harshitha S", title_style))
    story.append(Paragraph("Data Analyst | Python • SQL • Tableau", ParagraphStyle('Subtitle', parent=styles['Normal'], fontSize=12, alignment=1, spaceAfter=20)))
    story.append(Spacer(1, 12))

    # Contact Information
    story.append(Paragraph("Contact", heading_style))
    contact_data = [
        ["Email:", "msharshitha03.s@gmail.com"],
        ["Phone:", "+91-9980637439"],
        ["LinkedIn:", "linkedin.com/in/harshitha-s-96372727a"],
        ["GitHub:", "github.com/harshithascribe"]
    ]
    contact_table = Table(contact_data, colWidths=[80, 300])
    contact_table.setStyle(TableStyle([
        ('FONTSIZE', (0,0), (-1,-1), 10),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(contact_table)
    story.append(Spacer(1, 12))

    # Professional Summary
    story.append(Paragraph("Professional Summary", heading_style))
    summary = "Data Analyst & Full Stack Developer specializing in Python, data analytics, cloud platforms, and modern web technologies for scalable business solutions. Currently pursuing B.Tech in Information Technology (Cloud Computing) at Alliance University with a CGPA of 9.1."
    story.append(Paragraph(summary, normal_style))
    story.append(Spacer(1, 12))

    # Education
    story.append(Paragraph("Education", heading_style))
    education_data = [
        ["B.Tech in Information Technology (Cloud Computing)", "Alliance University", "2026", "CGPA: 9.1"],
        ["12th Grade (PUC)", "St Philomena PU College Bengaluru", "2022", "91.5%"],
        ["10th Grade (SSLC)", "St Philomena’s Public School, Bengaluru", "2020", "92.6%"]
    ]
    education_table = Table(education_data, colWidths=[200, 150, 50, 80])
    education_table.setStyle(TableStyle([
        ('FONTSIZE', (0,0), (-1,-1), 10),
        ('BACKGROUND', (0,0), (-1,0), colors.lightblue),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey)
    ]))
    story.append(education_table)
    story.append(Spacer(1, 12))

    # Skills
    story.append(Paragraph("Technical Skills", heading_style))
    skills_data = [
        ["Programming Languages", "Python, Django (Basics)"],
        ["Web Technologies", "HTML, CSS"],
        ["Database Technologies", "MySQL, SQL"],
        ["Tools & Platforms", "Git, GitHub, Linux, VS Code, Agile (SCRUM), ETL, Jenkins, Jira, AIML"],
        ["Cloud & Analytics", "Microsoft Azure, AWS (Basics), Adobe (UI), Data Structures, OOPs, DevOps, Tableau, CI/CD, Data Analytics, Data Visualization, NLP, Model Integration via APIs"]
    ]
    skills_table = Table(skills_data, colWidths=[150, 350])
    skills_table.setStyle(TableStyle([
        ('FONTSIZE', (0,0), (-1,-1), 10),
        ('BACKGROUND', (0,0), (-1,0), colors.lightblue),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey)
    ]))
    story.append(skills_table)
    story.append(Spacer(1, 12))

    # Projects
    story.append(Paragraph("Academic Projects", heading_style))
    project1 = "<b>Medical AI Bot – Symptom-Based Disease Prediction Chatbot</b><br/>• Developed an AI-powered chatbot using Python, scikit-learn, NLP, pyttsx3, pandas, GUI<br/>• Achieved 85% accuracy in disease prediction, reducing initial consultation time by 50%<br/>• Incorporated ethical data handling and natural language processing"
    story.append(Paragraph(project1, normal_style))
    story.append(Spacer(1, 6))

    project2 = "<b>Sales Dashboard using Tableau</b><br/>• Created interactive Tableau dashboards with comprehensive data cleaning and transformation<br/>• Enabled real-time data exploration and trend identification<br/>• Improved sales strategy effectiveness by 20% through better resource allocation"
    story.append(Paragraph(project2, normal_style))
    story.append(Spacer(1, 12))

    # Certifications
    story.append(Paragraph("Certifications", heading_style))
    certifications = [
        "Machine Learning – Corizo – 2024",
        "Oracle Analytics Cloud 2025 Certified Professional – Oracle – 2025",
        "Cloud Computing – Corizo – 2025",
        "Introduction to Microsoft Azure Cloud Services – Microsoft – 2024",
        "Cloud Data Engineer – Google – 2023",
        "Solutions Architect Job Simulation – AWS – 2025",
        "Software Engineering Job Simulation – Accenture – 2025",
        "Certificate of Completion Masterclass in Full Stack Development – NoviTech R&D Private Limited – 2025"
    ]
    for cert in certifications:
        story.append(Paragraph("• " + cert, normal_style))
    story.append(Spacer(1, 12))

    # Achievements
    story.append(Paragraph("Achievements & Participations", heading_style))
    achievements = [
        "HackerRank (Python 3★)",
        "Smart India Hackathon – 2024, 2025",
        "TechExpo – IIT Guwahati (National Level Technology Event)",
        "Tata Crucible Campus Quiz 2025 – Tata Group",
        "Code without Barriers – Microsoft – 2025",
        "Hackathon conducted by IBM – 2025",
        "Java Meetup – Oracle 2024",
        "Ideathon organized by Alliance University – 2022",
        "Stay Safe Online Quiz – GOI/G20 Presidency – 2023"
    ]
    for ach in achievements:
        story.append(Paragraph("• " + ach, normal_style))

    doc.build(story)

if __name__ == "__main__":
    create_resume()
